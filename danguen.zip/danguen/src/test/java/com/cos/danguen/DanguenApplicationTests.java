package com.cos.danguen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DanguenApplicationTests {

	@Test
	void contextLoads() {
	}

}
