package com.cos.danguen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DanguenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DanguenApplication.class, args);
	}

}
